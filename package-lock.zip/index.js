const dynamoose = require('dynamoose');

const personSchema = new dynamoose.Schema({
  name: String, 
  age: String, 
  height: String,
})

const PersonModel = dynamoose.model('People', personSchema);

expoerts.handler = async(event) =>{
  console.log('READING PERSON', event);
  let person;
  try{
    person = await PersonModel.create({
      id: 'testing_id',
      name: 'John Test Doe',
      height: '180',
    });
    console.log(person)
  }
  catch(e){
    console.error('ERROR: ', e);
  }

  const response = {
    statusCode: 200,
    body: JSON.stringify(`HELLO FROM NEW PERSON, ${person.name}`),
};
  return response;

}